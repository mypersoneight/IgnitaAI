import React, { useRef, useEffect, useState } from 'react';
import { ChatInput } from './components/ChatInput';
import { ChatMessage } from './components/ChatMessage';
import { ThemeToggle } from './components/ThemeToggle';
import { useChat } from './hooks/useChat';
import { IgnitaIcon } from './components/icons';
import { type PromptMode } from './types';

const WelcomeScreen = () => (
  <div className="text-center text-gray-500 dark:text-gray-400 my-auto flex flex-col items-center justify-center h-full">
    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mb-6">
        <IgnitaIcon className="w-14 h-14 text-white" />
    </div>
    <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-200 mb-2">Ignita Chat</h1>
    <p className="text-lg">Start a conversation and see the magic happen.</p>
    <p className="text-sm mt-2 text-gray-600 dark:text-gray-400">For better results, allow location access for personalized, area-specific responses.</p>
    <div className="mt-8 text-left grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl">
        <div className="bg-white/50 dark:bg-gray-800/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-1">Example Prompt</h3>
            <p className="text-sm">"Create an HTML login form with a username and password field."</p>
        </div>
        <div className="bg-white/50 dark:bg-gray-800/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-1">Try a location-based query</h3>
            <p className="text-sm">"What are some good Italian restaurants near me?"</p>
        </div>
    </div>
  </div>
);

function App() {
  const [promptMode, setPromptMode] = useState<PromptMode>('none');
  const [codeLanguage, setCodeLanguage] = useState<string>('JavaScript');
  const { messages, isLoading, sendMessage, sendVoiceMessage, stopGeneration, editMessage, regenerateResponse } = useChat(promptMode, codeLanguage);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (prompt: string) => {
    sendMessage(prompt);
    setPromptMode('none');
  };

  const handleSendVoiceMessage = (audioUrl: string, transcript: string) => {
    sendVoiceMessage(audioUrl, transcript);
    setPromptMode('none');
  };

  const handleStartEdit = (messageId: string) => {
    setEditingMessageId(messageId);
  };
  
  const handleCancelEdit = () => {
    setEditingMessageId(null);
  };

  const handleSaveEdit = (messageId: string, newContent: string) => {
    editMessage(messageId, newContent);
    setEditingMessageId(null);
  };

  const handleRegenerate = (messageId: string) => {
    regenerateResponse(messageId);
  };

  return (
    <div className="flex flex-col h-screen font-sans bg-gray-100 dark:bg-gray-950 text-gray-900 dark:text-gray-100 items-center md:p-4">
      <div className="w-full max-w-4xl flex-grow flex flex-col bg-white dark:bg-gray-900 shadow-2xl rounded-lg overflow-hidden">
        <header className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800 flex-shrink-0">
          <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-600">
            Ignita Rich Chatbot
          </h1>
          <ThemeToggle />
        </header>

        <main className="flex-grow p-4 md:p-6 overflow-y-auto">
            {messages.length === 0 ? (
              <WelcomeScreen />
            ) : (
              <div className="space-y-6">
                {messages.map((msg, index) => {
                  let lastUserPrompt = '';
                  if (msg.role === 'model') {
                    for (let i = index - 1; i >= 0; i--) {
                      if (messages[i].role === 'user') {
                        lastUserPrompt = messages[i].content;
                        break;
                      }
                    }
                  }
                  return (
                    <ChatMessage 
                        key={msg.id} 
                        message={msg} 
                        lastUserPrompt={lastUserPrompt} 
                        isEditing={editingMessageId === msg.id}
                        onStartEdit={handleStartEdit}
                        onCancelEdit={handleCancelEdit}
                        onSaveEdit={handleSaveEdit}
                        onRegenerate={handleRegenerate}
                    />
                  );
                })}
              </div>
            )}
            <div ref={messagesEndRef} />
        </main>

        <footer className="flex-shrink-0">
            <ChatInput 
                onSendMessage={handleSendMessage}
                onSendVoiceMessage={handleSendVoiceMessage}
                onStopGeneration={stopGeneration}
                isLoading={isLoading}
                promptMode={promptMode}
                setPromptMode={setPromptMode}
                codeLanguage={codeLanguage}
                setCodeLanguage={setCodeLanguage}
            />
        </footer>
      </div>
    </div>
  );
}

export default App;