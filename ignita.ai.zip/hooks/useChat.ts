import { useState, useRef, useCallback, useEffect } from 'react';
import { type Message, type Source, type Location, type PromptMode } from '../types';
import { createChat } from '../services/geminiService';
import { type Chat, type GenerateContentResponse, type Content } from '@google/genai';

const mapMessagesToHistory = (msgs: Message[]): Content[] => {
    // Filter out loading messages and strip image markdown from history.
    return msgs.filter(m => m.content !== '...').map(msg => ({
        role: msg.role,
        parts: [{ text: msg.content.replace(/!\[.*?\]\(https?:\/\/[^\s)]+\)\s*/g, '') }],
    }));
};

export const useChat = (promptMode: PromptMode, codeLanguage: string) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [location, setLocation] = useState<Location | null>(null);
  const chatRef = useRef<Chat | null>(null);
  const stopRef = useRef<boolean>(false);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting user location:", error.message);
        }
      );
    }
  }, []);

  const performStreaming = useCallback(async (prompt: string, historyForApi: Message[], modelMessageIdToUpdate: string) => {
      chatRef.current = createChat(mapMessagesToHistory(historyForApi), location ?? undefined);
      setIsLoading(true);
      stopRef.current = false;
      
      try {
        const stream = await chatRef.current.sendMessageStream({ message: prompt });
        let finalText = '';
        let sources: Source[] | undefined = undefined;
        
        for await (const chunk of stream) {
          if (stopRef.current) {
            console.log('Streaming stopped by user.');
            break;
          }
          finalText += chunk.text;
          
          const groundingChunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
          if (groundingChunks) {
            const allSources: Source[] = groundingChunks
              .map((c: any) => {
                if (c.web) return { uri: c.web.uri, title: c.web.title };
                if (c.maps) return { uri: c.maps.uri, title: c.maps.title };
                return null;
              })
              .filter((s: Source | null): s is Source => s !== null);
  
            if (allSources.length > 0) {
              sources = [...new Map(allSources.map(item => [item['uri'], item])).values()];
            }
          }

          setMessages((prev) =>
            prev.map((m) =>
              m.id === modelMessageIdToUpdate ? { ...m, content: finalText + '...' } : m
            )
          );
        }
        
        setMessages((prev) =>
            prev.map((m) =>
              m.id === modelMessageIdToUpdate ? { ...m, content: finalText, sources } : m
            )
        );

      } catch (error: any) {
        console.error('Error sending message:', error);
        
        let errorMessage = 'Sorry, I encountered an error. Please try again. 🚨';
        let isQuotaError = false;

        // Check for quota error status by trying to parse the error or matching strings
        try {
            // Error might be a stringified JSON from the API
            const errorDetails = typeof error.message === 'string' ? JSON.parse(error.message) : error;
            if (errorDetails?.error?.status === 'RESOURCE_EXHAUSTED') {
                isQuotaError = true;
            }
        } catch (e) {
            // Fallback to string matching if parsing fails
            if (String(error.message).includes('RESOURCE_EXHAUSTED') || String(error.message).includes('exceeded your current quota')) {
                isQuotaError = true;
            }
        }

        if (isQuotaError) {
            errorMessage = `QUOTA_ERROR::You've exceeded the API quota for the current key. Please select a different API key with available quota and try again. You can learn more about billing [here](https://ai.google.dev/gemini-api/docs/billing).`;
        }

         setMessages((prev) =>
            prev.map((m) =>
              m.id === modelMessageIdToUpdate ? { ...m, content: errorMessage } : m
            )
          );
      } finally {
        setIsLoading(false);
      }
  }, [location]);
  
  const modifyPrompt = useCallback((prompt: string): string => {
      switch (promptMode) {
          case 'explain':
              return `Please provide a detailed and in-depth explanation of the following topic. Break it down into fundamental concepts and use examples where possible:\n\n"${prompt}"`;
          case 'code':
              return `Write a code snippet for the following task using the ${codeLanguage} programming language. Please only provide the code block unless an explanation is requested:\n\n"${prompt}"`;
          case 'research':
              return `Research the following topic using web sources and provide a comprehensive summary. Please cite your sources:\n\n"${prompt}"`;
          case 'short':
              return `Provide a concise answer, no more than 5 lines, for the following:\n\n"${prompt}"`;
          case 'none':
          default:
              return prompt;
      }
  }, [promptMode, codeLanguage]);

  const sendMessage = useCallback((prompt: string) => {
    const modifiedPrompt = modifyPrompt(prompt);
    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: prompt };
    const modelMessageId = (Date.now() + 1).toString();
    const modelMessage: Message = { id: modelMessageId, role: 'model', content: '...' };
    
    const newMessages = [...messages, userMessage, modelMessage];
    setMessages(newMessages);
    // Pass the message history *before* the current message.
    performStreaming(modifiedPrompt, messages, modelMessageId);
  }, [messages, performStreaming, modifyPrompt]);

  const sendVoiceMessage = useCallback((audioUrl: string, transcript: string) => {
    if (!transcript) return;
    const modifiedTranscript = modifyPrompt(transcript);
    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: transcript, audioUrl };
    const modelMessageId = (Date.now() + 1).toString();
    const modelMessage: Message = { id: modelMessageId, role: 'model', content: '...' };
    
    const newMessages = [...messages, userMessage, modelMessage];
    setMessages(newMessages);
    // Pass the message history *before* the current message.
    performStreaming(modifiedTranscript, messages, modelMessageId);
  }, [messages, performStreaming, modifyPrompt]);
  
  const editMessage = useCallback((messageId: string, newContent: string) => {
    const index = messages.findIndex(m => m.id === messageId);
    if (index === -1) return;
    const history = messages.slice(0, index);
    const userMessage: Message = { id: messageId, role: 'user', content: newContent };
    const modelMessageId = (Date.now() + 1).toString();
    const modelMessage: Message = { id: modelMessageId, role: 'model', content: '...' };
    
    const newMessages = [...history, userMessage, modelMessage];
    setMessages(newMessages);
    // Pass the history before the edited message.
    performStreaming(newContent, history, modelMessageId);
  }, [messages, performStreaming]);

  const regenerateResponse = useCallback((modelMessageId: string) => {
      const index = messages.findIndex(m => m.id === modelMessageId);
      if (index < 1 || messages[index - 1].role !== 'user') return;
      const userMessage = messages[index - 1];
      const history = messages.slice(0, index - 1);
      
      const newModelMessageId = (Date.now() + 1).toString();
      const modelMessage: Message = { id: newModelMessageId, role: 'model', content: '...' };
      
      const newMessages = [...history, userMessage, modelMessage];
      setMessages(newMessages);
      // Pass the history before the user message that prompted this regeneration.
      performStreaming(userMessage.content, history, newModelMessageId);
  }, [messages, performStreaming]);
  
  const stopGeneration = useCallback(() => {
    stopRef.current = true;
    setIsLoading(false);
  }, []);

  return { messages, isLoading, sendMessage, stopGeneration, editMessage, regenerateResponse, sendVoiceMessage };
};