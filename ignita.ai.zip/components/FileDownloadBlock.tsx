import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { DownloadIcon } from './icons';

interface FileDownloadBlockProps {
  content: string;
  fileType: string;
  fileName: string;
}

const getMimeType = (fileType: string) => {
  switch (fileType.toLowerCase()) {
    case 'txt': return 'text/plain';
    case 'json': return 'application/json';
    case 'csv': return 'text/csv';
    case 'html': return 'text/html';
    case 'xml': return 'application/xml';
    default: return 'application/octet-stream';
  }
};

const PdfContent = React.forwardRef<HTMLDivElement, { content: string, title: string }>(({ content, title }, ref) => (
  <div ref={ref} style={{ width: '595px', padding: '40px', boxSizing: 'border-box', background: 'white', color: '#111827', fontFamily: 'Helvetica, sans-serif' }}>
    <div style={{ textAlign: 'center', marginBottom: '30px' }}>
      <h1 style={{ fontSize: '22px', margin: 0, fontWeight: 'bold', color: '#164e63' }}>{title}</h1>
    </div>
    <div style={{ padding: '20px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h2: ({ node, ...props }) => <h2 style={{ fontSize: '16px', color: '#0e7490', borderBottom: '1px solid #a5f3fc', paddingBottom: '4px', marginTop: '20px', marginBottom: '14px', fontWeight: 'bold' }} {...props} />,
          h3: ({ node, ...props }) => <h3 style={{ fontSize: '14px', color: '#155e75', marginTop: '18px', marginBottom: '6px', fontWeight: 'bold' }} {...props} />,
          p: ({ node, ...props }) => <p style={{ fontSize: '11px', lineHeight: '1.6', marginBottom: '10px' }} {...props} />,
          a: ({ node, href, ...props }) => <a href={href} style={{ color: '#06b6d4', textDecoration: 'underline' }} {...props} />,
          ul: ({ node, ...props }) => <ul style={{ paddingLeft: '20px', marginBottom: '12px', listStyleType: 'disc' }} {...props} />,
          ol: ({ node, children, ...props }) => {
              const listItems = React.Children.toArray(children);
              return (
                  <ol style={{ paddingLeft: 0, listStyle: 'none', margin: '20px 0' }} {...props}>
                      {listItems.map((item, index) => (
                          <React.Fragment key={index}>
                              {item}
                              {index < listItems.length - 1 && (
                                  <div style={{ display: 'flex', justifyContent: 'center', height: '20px', margin: '2px 0' }}>
                                      <div style={{
                                          width: 0,
                                          height: 0,
                                          borderLeft: '5px solid transparent',
                                          borderRight: '5px solid transparent',
                                          borderTop: '8px solid #67e8f9',
                                      }}></div>
                                  </div>
                              )}
                          </React.Fragment>
                      ))}
                  </ol>
              );
          },
          li: ({ node, ...props }) => <li style={{ backgroundColor: '#f0f9ff', border: '1px solid #bae6fd', borderRadius: '6px', padding: '8px 12px', fontSize: '11px', textAlign: 'center' }} {...props} />,
          code: ({ node, inline, children, className, ...props }: { node?: any; inline?: boolean; children: React.ReactNode; className?: string }) => (
            inline ?
            <code style={{ backgroundColor: '#f0f9ff', color: '#0891b2', padding: '2px 4px', borderRadius: '4px', fontFamily: 'monospace', fontSize: '10px' }} className={className} {...props}>{children}</code> :
            <pre style={{ backgroundColor: '#1e293b', color: '#e2e8f0', padding: '12px', borderRadius: '8px', whiteSpace: 'pre-wrap', fontFamily: 'monospace', fontSize: '10px', lineHeight: '1.5' }}><code className={className} {...props}>{children}</code></pre>
          ),
          blockquote: ({ node, ...props }) => <blockquote style={{ borderLeft: '3px solid #a5f3fc', paddingLeft: '14px', margin: '14px 0', color: '#155e75' }} {...props} />,
          img: ({ node, src, alt, ...props }) => <img src={src} alt={alt} style={{ maxWidth: '100%', height: 'auto', borderRadius: '8px', margin: '14px 0' }} {...props} />,
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  </div>
));


export const FileDownloadBlock = ({ content, fileType, fileName }: FileDownloadBlockProps) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const pdfContentRef = React.useRef<HTMLDivElement>(null);
  
  let docTitle = fileName;
  let docContent = content;

  if (fileType === 'pdf') {
      const titleMatch = content.match(/^#\s+(.*)/);
      if (titleMatch) {
          docTitle = titleMatch[1];
          docContent = content.substring(titleMatch[0].length).trim();
      }
  }

  const handleDownload = async () => {
    if (fileType === 'pdf') {
      if (!pdfContentRef.current) return;
      setIsGenerating(true);
      try {
        const canvas = await html2canvas(pdfContentRef.current, {
          scale: 2,
          useCORS: true,
        });
        
        const imgData = canvas.toDataURL('image/png');
        
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'pt',
          format: 'a4',
        });

        const pdfWidth = pdf.internal.pageSize.getWidth();
        const imgProps = pdf.getImageProperties(imgData);
        const imgHeight = (imgProps.height * pdfWidth) / imgProps.width;
        
        let heightLeft = imgHeight;
        let position = 0;

        pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeight);
        heightLeft -= pdf.internal.pageSize.getHeight();

        while (heightLeft > 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeight);
          heightLeft -= pdf.internal.pageSize.getHeight();
        }
        
        pdf.save(fileName);

      } catch (error) {
        console.error("Error generating PDF:", error);
      } finally {
        setIsGenerating(false);
      }
    } else {
      const mimeType = getMimeType(fileType);
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="my-4 p-4 border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-lg font-semibold text-green-700 dark:text-green-300 truncate">
          {fileType === 'pdf' ? 'Topic: ' : 'File Ready: '}
          <span className="font-mono text-sm bg-green-100 dark:bg-green-800 p-1 rounded">{docTitle}</span>
        </h3>
        <button
          onClick={handleDownload}
          disabled={isGenerating}
          className="flex-shrink-0 flex items-center px-3 py-1.5 text-sm font-medium text-green-600 dark:text-green-400 bg-white dark:bg-gray-800 border border-green-200 dark:border-green-700 rounded-md hover:bg-green-100 dark:hover:bg-green-900 transition-colors disabled:opacity-50 disabled:cursor-wait"
          aria-label={`Download ${fileName}`}
        >
          <DownloadIcon className="w-4 h-4 mr-2" />
          {isGenerating ? 'Generating...' : `Download ${fileType.toUpperCase()}`}
        </button>
      </div>
      {fileType === 'pdf' && (
        <p className="text-xs text-yellow-800 dark:text-yellow-300 mb-3 p-2 bg-yellow-100 dark:bg-yellow-900/30 rounded-md border border-yellow-200 dark:border-yellow-800">
          <strong>Please note:</strong> The generated PDF is an automated conversion and may have some design or alignment inconsistencies.
        </p>
      )}
      <div className="max-h-60 overflow-y-auto bg-white dark:bg-gray-800/50 p-3 rounded-md">
          {fileType === 'pdf' && (
              <div style={{ position: 'absolute', left: '-9999px', top: 0 }}>
                  <PdfContent content={docContent} title={docTitle} ref={pdfContentRef} />
              </div>
          )}
        <pre className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap font-mono">
          <code>
            {content}
          </code>
        </pre>
      </div>
    </div>
  );
};