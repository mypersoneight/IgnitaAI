import React, { useState, useRef, useEffect } from 'react';
import { SendIcon, StopIcon, MicrophoneIcon, XMarkIcon } from './icons';
import { PromptToolbar } from './PromptToolbar';
// FIX: Import the AIStudio type from the centralized types.ts file to resolve a global type conflict.
import { type PromptMode, type AIStudio } from '../types';

// FIX: Add type definitions for the Web Speech API to resolve the 'SpeechRecognition' not found error and allow for proper type checking.
interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
  readonly length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  readonly isFinal: boolean;
  readonly length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
  readonly transcript: string;
}

interface SpeechRecognitionStatic {
    new(): SpeechRecognition;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  onresult: (event: SpeechRecognitionEvent) => void;
  start: () => void;
  stop: () => void;
}

// FIX: The AIStudio interface has been moved to types.ts to resolve the global type conflict.
declare global {
  interface Window {
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
    aistudio?: AIStudio;
  }
}

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  onSendVoiceMessage: (audioUrl: string, transcript: string) => void;
  onStopGeneration: () => void;
  isLoading: boolean;
  promptMode: PromptMode;
  setPromptMode: (mode: PromptMode) => void;
  codeLanguage: string;
  setCodeLanguage: (lang: string) => void;
}

// FIX: Rename the `SpeechRecognition` constant to `SpeechRecognitionApi` to avoid a name collision with the `SpeechRecognition` type interface.
const SpeechRecognitionApi = window.SpeechRecognition || window.webkitSpeechRecognition;

export const ChatInput = ({ onSendMessage, onSendVoiceMessage, onStopGeneration, isLoading, promptMode, setPromptMode, codeLanguage, setCodeLanguage }: ChatInputProps) => {
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const handleVoiceClick = async () => {
    if (isRecording) {
      mediaRecorderRef.current?.stop();
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      if (!SpeechRecognitionApi) {
        alert("Speech recognition is not supported in this browser. Please try Chrome or Edge.");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        // 1. Configure MediaRecorder
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;
        audioChunksRef.current = [];
        mediaRecorder.addEventListener("dataavailable", event => {
          audioChunksRef.current.push(event.data);
        });
        
        // 2. Configure SpeechRecognition
        const recognition = new SpeechRecognitionApi();
        recognitionRef.current = recognition;
        recognition.continuous = true;
        recognition.interimResults = true;
        let finalTranscript = '';

        recognition.onresult = (event) => {
          let interimTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript;
            } else {
              interimTranscript += event.results[i][0].transcript;
            }
          }
          setInput(finalTranscript + interimTranscript);
        };
        
        // 3. Link MediaRecorder stop event to send the message
        mediaRecorder.addEventListener("stop", () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const audioUrl = URL.createObjectURL(audioBlob);
          onSendVoiceMessage(audioUrl, finalTranscript.trim() || input);
          setInput('');
          stream.getTracks().forEach(track => track.stop());
        });

        // 4. Start recording and recognition
        mediaRecorder.start();
        recognition.start();
        setIsRecording(true);

      } catch (err) {
        console.error("Error accessing microphone:", err);
        alert("Could not access the microphone. Please ensure you have granted permission in your browser settings.");
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading && !isRecording) {
      onSendMessage(input);
      setInput('');
    }
  };
  
  const handleStop = () => {
    onStopGeneration();
  };
  
  useEffect(() => {
    return () => {
      // Cleanup refs on unmount
      mediaRecorderRef.current?.stream?.getTracks().forEach(track => track.stop());
      recognitionRef.current?.stop();
    };
  }, []);

  const ModeIndicator = () => {
    if (promptMode === 'none') return null;

    const modeText = promptMode === 'code' ? `Code: ${codeLanguage}` : promptMode.charAt(0).toUpperCase() + promptMode.slice(1);
    
    return (
      <div className="absolute bottom-full left-0 mb-2 w-full flex justify-center pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1 text-xs font-medium text-white bg-gray-800/80 dark:bg-gray-950/80 rounded-full backdrop-blur-sm pointer-events-auto">
          <span>Mode: <strong>{modeText}</strong></span>
          <button onClick={() => setPromptMode('none')} className="p-0.5 rounded-full hover:bg-gray-600">
            <XMarkIcon className="w-3 h-3" />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="relative">
        <ModeIndicator />
        <form 
        onSubmit={handleSubmit} 
        className="flex items-center gap-2 md:gap-4 p-4 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-t border-gray-200 dark:border-gray-800"
        >
        <PromptToolbar
            promptMode={promptMode}
            setPromptMode={setPromptMode}
            codeLanguage={codeLanguage}
            setCodeLanguage={setCodeLanguage}
        />
        <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isRecording ? "Listening..." : "Type your message..."}
            className="flex-grow p-3 bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 transition-shadow"
            disabled={isLoading || isRecording}
            aria-label="Chat input"
        />
        {isLoading ? (
            <button
            type="button"
            onClick={handleStop}
            className="p-3 w-12 h-12 flex-shrink-0 bg-red-500 text-white rounded-full hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-400 dark:focus:ring-offset-gray-900 transition-colors flex items-center justify-center"
            aria-label="Stop generation"
            >
            <StopIcon className="w-6 h-6" />
            </button>
        ) : (
            <>
            <button
                type="button"
                onClick={handleVoiceClick}
                className={`p-3 w-12 h-12 flex-shrink-0 text-white rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-gray-900 transition-colors flex items-center justify-center ${
                    isRecording 
                    ? 'bg-red-500 hover:bg-red-600 focus:ring-red-400 animate-pulse' 
                    : 'bg-gray-500 hover:bg-gray-600 focus:ring-gray-400'
                }`}
                aria-label={isRecording ? "Stop recording" : "Start recording"}
            >
                {isRecording ? <StopIcon className="w-6 h-6" /> : <MicrophoneIcon className="w-6 h-6" />}
            </button>

            <button
                type="submit"
                className="p-3 w-12 h-12 flex-shrink-0 bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-full hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900 transition-opacity flex items-center justify-center"
                aria-label="Send message"
                disabled={!input.trim() || isRecording}
            >
                <SendIcon className="w-6 h-6" />
            </button>
            </>
        )}
        </form>
    </div>
  );
};