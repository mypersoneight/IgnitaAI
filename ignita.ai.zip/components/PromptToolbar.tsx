import React, { useState, useRef, useEffect } from 'react';
import { type PromptMode } from '../types';
import { WandIcon } from './icons';

interface PromptToolbarProps {
  promptMode: PromptMode;
  setPromptMode: (mode: PromptMode) => void;
  codeLanguage: string;
  setCodeLanguage: (lang: string) => void;
}

const LANGUAGES = [
  'ActionScript', 'Ada', 'Apex', 'Assembly', 'Bash', 'C', 'C#', 'C++', 'Clojure', 'COBOL', 
  'CoffeeScript', 'Crystal', 'CSS', 'Dart', 'Delphi', 'Dockerfile', 'Elixir', 'Elm', 
  'Erlang', 'F#', 'Fortran', 'Go', 'Groovy', 'Haskell', 'Haxe', 'HTML', 'Java', 
  'JavaScript', 'Julia', 'Kotlin', 'LaTeX', 'Lisp', 'Lua', 'MATLAB', 'Objective-C', 
  'OCaml', 'Pascal', 'Perl', 'PHP', 'PowerShell', 'Prolog', 'Python', 'R', 'Ruby', 
  'Rust', 'Scala', 'Scheme', 'Shell', 'Solidity', 'SQL', 'Swift', 'Tcl', 'TypeScript', 
  'VB.NET', 'Verilog', 'VHDL', 'Vim script', 'Zig'
];

export const PromptToolbar = ({ promptMode, setPromptMode, codeLanguage, setCodeLanguage }: PromptToolbarProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showCodeMenu, setShowCodeMenu] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setShowCodeMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleModeSelect = (mode: PromptMode) => {
    if (mode === 'code') {
      setShowCodeMenu(true);
    } else {
      setPromptMode(mode);
      setIsOpen(false);
    }
  };

  const handleLanguageSelect = (lang: string) => {
    setCodeLanguage(lang);
    setPromptMode('code');
    setShowCodeMenu(false);
    setIsOpen(false);
  };

  const menuClass = "absolute bottom-full mb-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden z-10";

  const MenuItem = ({ children, onClick }: { children: React.ReactNode; onClick: () => void }) => (
    <button onClick={onClick} className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2">
      {children}
    </button>
  );

  return (
    <div className="relative" ref={wrapperRef}>
      <button
        type="button"
        onClick={() => setIsOpen(p => !p)}
        className={`p-3 w-12 h-12 flex-shrink-0 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-gray-900 transition-colors flex items-center justify-center ${
            promptMode !== 'none' 
            ? 'bg-gradient-to-br from-blue-500 to-purple-600 text-white focus:ring-blue-500' 
            : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600 focus:ring-gray-400'
        }`}
        aria-label="Prompt options"
      >
        <WandIcon className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className={menuClass}>
          {!showCodeMenu ? (
            <>
              <MenuItem onClick={() => handleModeSelect('explain')}>📖 Explain</MenuItem>
              <MenuItem onClick={() => handleModeSelect('code')}>💻 Code</MenuItem>
              <MenuItem onClick={() => handleModeSelect('research')}>🌐 Research</MenuItem>
              <MenuItem onClick={() => handleModeSelect('short')}>✏️ Short</MenuItem>
            </>
          ) : (
            <div className="max-h-60 overflow-y-auto">
                <MenuItem onClick={() => setShowCodeMenu(false)}>⬅️ Back</MenuItem>
                {LANGUAGES.map(lang => (
                    <MenuItem key={lang} onClick={() => handleLanguageSelect(lang)}>
                        {lang.toLowerCase() === codeLanguage.toLowerCase() && <span className="text-blue-500 font-bold mr-1">•</span>}
                        {lang}
                    </MenuItem>
                ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};