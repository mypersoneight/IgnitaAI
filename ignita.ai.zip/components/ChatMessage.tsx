import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { type Message, type Source } from '../types';
import { CodeBlock } from './CodeBlock';
import { StepsBlock } from './StepsBlock';
import { UserIcon, IgnitaIcon, ExternalLinkIcon, EditIcon, CopyIcon, CheckIcon, RegenerateIcon, LikeIcon, DislikeIcon } from './icons';
import { FileDownloadBlock } from './FileDownloadBlock';

interface ChatMessageProps {
  message: Message;
  lastUserPrompt?: string;
  isEditing: boolean;
  onStartEdit: (messageId: string) => void;
  onCancelEdit: () => void;
  onSaveEdit: (messageId:string, newContent: string) => void;
  onRegenerate: (messageId: string) => void;
}

const LoadingIndicator = () => (
    <div className="flex items-center space-x-1">
        <div className="w-2 h-2 bg-gray-500 rounded-full loading-dot"></div>
        <div className="w-2 h-2 bg-gray-500 rounded-full loading-dot"></div>
        <div className="w-2 h-2 bg-gray-500 rounded-full loading-dot"></div>
    </div>
);

const ActionButton: React.FC<{onClick: () => void; title: string; children: React.ReactNode;}> = ({ onClick, title, children }) => (
    <button onClick={onClick} title={title} className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-gray-900">
        {children}
    </button>
);

const Sources: React.FC<{ sources: Source[] }> = ({ sources }) => {
    if (!sources || sources.length === 0) return null;
    
    return (
        <div className="mt-4 pt-3 border-t border-gray-300 dark:border-gray-600">
            <h4 className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2 uppercase tracking-wider">Sources</h4>
            <div className="flex flex-wrap gap-2">
                {sources.map((source, index) => (
                    <a
                        key={index}
                        href={source.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-xs bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded-full hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                    >
                        <ExternalLinkIcon className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">{source.title || new URL(source.uri).hostname}</span>
                    </a>
                ))}
            </div>
        </div>
    );
};

const MessageActions: React.FC<{message: Message; onStartEdit: (id:string) => void; onRegenerate: (id:string) => void;}> = ({ message, onStartEdit, onRegenerate }) => {
    const [liked, setLiked] = useState(false);
    const [disliked, setDisliked] = useState(false);
    const [copied, setCopied] = useState(false);
    
    const handleCopy = () => {
        navigator.clipboard.writeText(message.content).then(() => {
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        });
    };

    return (
        <div className="flex items-center justify-end gap-1 mt-1 pr-2">
            {message.role === 'user' && (
                <>
                    <ActionButton onClick={() => onStartEdit(message.id)} title="Edit">
                        <EditIcon className="w-5 h-5" />
                    </ActionButton>
                    <ActionButton onClick={handleCopy} title="Copy">
                        {copied ? <CheckIcon className="w-5 h-5 text-green-500" /> : <CopyIcon className="w-5 h-5" />}
                    </ActionButton>
                </>
            )}
            {message.role === 'model' && (
                 <>
                    <ActionButton onClick={() => onRegenerate(message.id)} title="Regenerate response">
                        <RegenerateIcon className="w-5 h-5" />
                    </ActionButton>
                    <ActionButton onClick={() => { setLiked(p => !p); if (!liked) setDisliked(false); }} title="Like">
                        <LikeIcon className={`w-5 h-5 ${liked ? 'text-blue-500 fill-blue-500' : ''}`} />
                    </ActionButton>
                    <ActionButton onClick={() => { setDisliked(p => !p); if (!disliked) setLiked(false); }} title="Dislike">
                        <DislikeIcon className={`w-5 h-5 ${disliked ? 'text-red-500' : ''}`} />
                    </ActionButton>
                    <ActionButton onClick={handleCopy} title="Copy">
                         {copied ? <CheckIcon className="w-5 h-5 text-green-500" /> : <CopyIcon className="w-5 h-5" />}
                    </ActionButton>
                </>
            )}
        </div>
    );
};

// FIX: Explicitly type component with React.FC to correctly handle props like 'key' when used in a list.
export const ChatMessage: React.FC<ChatMessageProps> = ({ message, lastUserPrompt, isEditing, onStartEdit, onCancelEdit, onSaveEdit, onRegenerate }) => {
  const isModel = message.role === 'model';
  const isUser = message.role === 'user';
  const isLoading = isModel && message.content === '...';
  const isQuotaError = message.content.startsWith('QUOTA_ERROR::');
  const contentToRender = isQuotaError ? message.content.replace('QUOTA_ERROR::', '') : message.content;

  const keywords = ['step', 'how', 'what process'];
  const shouldShowSteps = isModel && lastUserPrompt && keywords.some(kw => lastUserPrompt.toLowerCase().includes(kw));

  const [editedContent, setEditedContent] = useState(message.content);

  const handleSave = () => {
    if (editedContent.trim() !== message.content.trim()) {
        onSaveEdit(message.id, editedContent);
    } else {
        onCancelEdit();
    }
  };

  const handleRetryWithNewKey = async () => {
    if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
        try {
            await window.aistudio.openSelectKey();
            // After key selection, regenerate the response
            onRegenerate(message.id);
        } catch (error) {
            console.error("Error opening API key selection:", error);
            alert("An error occurred while trying to select a new API key.");
        }
    } else {
        console.error("aistudio.openSelectKey is not available.");
        alert("Could not open API key selection. This feature may not be available in your current environment.");
    }
  };

  const markdownComponents = {
    code({ node, inline, className, children, ...props }: { node?: any; inline?: boolean; className?: string; children: React.ReactNode; [key: string]: any; }) {
        const fileMatch = /language-file-(\w+)/.exec(className || '');
        if (fileMatch && !inline) {
            const fileType = fileMatch[1];
            const content = String(children).replace(/\n$/, '');
            const fileName = `ignita-export.${fileType}`;
            return <FileDownloadBlock content={content} fileType={fileType} fileName={fileName} />;
        }

        const langMatch = /language-(\w+)/.exec(className || '');

        if (!inline && !langMatch) {
            return (
                <pre className="my-4 p-4 bg-gray-200 dark:bg-gray-800 rounded-lg overflow-x-auto">
                    <code className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap font-mono text-sm">{children}</code>
                </pre>
            );
        }
        
        return <CodeBlock inline={inline} className={className}>{children}</CodeBlock>;
    },
    ol({ node, children, ...props }: { node?: any; children?: React.ReactNode; [key: string]: any; }) {
        return shouldShowSteps 
            ? <StepsBlock><ol {...props}>{children}</ol></StepsBlock>
            : <ol className="list-decimal list-inside my-4 pl-4" {...props}>{children}</ol>;
    },
    ul({ node, children, ...props }: { node?: any; children?: React.ReactNode; [key: string]: any; }) {
        return shouldShowSteps 
            ? <StepsBlock><ul {...props}>{children}</ul></StepsBlock>
            : <ul className="list-disc list-inside my-4 pl-4" {...props}>{children}</ul>;
    },
    a({ node, href, children, ...props }: { node?: any; href?: string; children: React.ReactNode; [key: string]: any; }) {
        // Different styling for the quota error link vs. standard markdown links
        if (href === 'https://ai.google.dev/gemini-api/docs/billing') {
            return (
                <a href={href} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline dark:text-blue-400">
                    {children}
                </a>
            );
        }
        return (
            <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-500 text-white font-semibold px-3 py-1.5 rounded-lg my-1 hover:bg-green-600 transition-colors no-underline"
                {...props}
            >
                Open {children}
                <ExternalLinkIcon className="w-4 h-4" />
            </a>
        );
    },
    img() {
        // Return null to completely remove images from the chat display.
        return null;
    }
  };

  return (
    <div>
        <div className="flex items-start gap-4">
        {isModel ? (
            <div className="w-8 h-8 flex-shrink-0 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white">
            <IgnitaIcon className="w-5 h-5" />
            </div>
        ) : (
            <div className="w-8 h-8 flex-shrink-0 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-300">
            <UserIcon className="w-5 h-5" />
            </div>
        )}
        
        <div className="flex-grow">
            <h2 className="text-sm font-bold text-gray-900 dark:text-gray-100 mb-1">
            {isModel ? 'Ignita' : 'You'}
            </h2>
            
            {isEditing ? (
                <div>
                    <textarea
                        value={editedContent}
                        onChange={(e) => setEditedContent(e.target.value)}
                        className="w-full p-3 bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-shadow text-lg"
                        rows={3}
                    />
                    <div className="flex justify-end items-center gap-2 mt-2">
                        <button onClick={onCancelEdit} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-200 dark:bg-gray-700 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600">Cancel</button>
                        <button onClick={handleSave} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">Save & Submit</button>
                    </div>
                </div>
            ) : (
                <div 
                    className={`rounded-xl p-4 ${isQuotaError ? 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700' : 'bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800'}`}
                >
                {isLoading ? (
                    <LoadingIndicator />
                ) : (
                    <>
                        {message.audioUrl && isUser && (
                            <div className="mb-3">
                                <audio controls src={message.audioUrl} className="w-full h-10" />
                            </div>
                        )}
                        <div className="text-gray-800 dark:text-gray-200 text-lg whitespace-pre-wrap font-medium leading-relaxed">
                            {isModel ? (
                                <>
                                    <ReactMarkdown remarkPlugins={[remarkGfm]} components={markdownComponents}>{contentToRender}</ReactMarkdown>
                                    {isQuotaError && (
                                        <div className="mt-4">
                                            <button 
                                                onClick={handleRetryWithNewKey}
                                                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
                                            >
                                                Select API Key & Retry
                                            </button>
                                        </div>
                                    )}
                                </>
                            ) : <p className="text-gray-800 dark:text-gray-200 text-lg whitespace-pre-wrap font-medium leading-relaxed">{message.content}</p>}
                        </div>
                        {message.sources && <Sources sources={message.sources} />}
                    </>
                )}
                </div>
            )}
        </div>
        </div>
        {!isLoading && !isEditing && (
            <div className="pl-12">
                <MessageActions message={message} onStartEdit={onStartEdit} onRegenerate={onRegenerate} />
            </div>
        )}
    </div>
  );
};