import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { CopyIcon, CheckIcon, EyeIcon } from './icons';

interface CodeBlockProps {
  inline?: boolean;
  className?: string;
  children: React.ReactNode;
}

const PreviewModal = ({ htmlContent, onClose }: { htmlContent: string; onClose: () => void }) => (
    <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center"
        onClick={onClose}
    >
        <div 
            className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-11/12 h-5/6 flex flex-col"
            onClick={(e) => e.stopPropagation()}
        >
            <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">HTML Preview</h3>
                <button 
                    onClick={onClose}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
                >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            <iframe
                srcDoc={htmlContent}
                title="HTML Preview"
                className="w-full h-full border-0"
                sandbox="allow-scripts allow-forms allow-popups allow-modals"
            />
        </div>
    </div>
);

export const CodeBlock: React.FC<CodeBlockProps> = ({ inline, className, children }) => {
  const [copied, setCopied] = useState(false);
  const [showHtmlPreview, setShowHtmlPreview] = useState(false);
  
  const match = /language-(\w+)/.exec(className || '');
  const lang = match ? match[1] : 'text';
  const rawCode = String(children).replace(/\n$/, '');

  const handleCopy = () => {
    navigator.clipboard.writeText(rawCode).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  if (inline) {
    return <code className="bg-gray-200 dark:bg-gray-700 text-primary-600 dark:text-primary-400 px-1 py-0.5 rounded-md font-mono text-sm">{children}</code>;
  }

  return (
    <div className="my-4 rounded-lg overflow-hidden bg-[#2d2d2d] shadow-lg">
      <div className="flex justify-between items-center px-4 py-2 bg-gray-800 text-gray-300 text-xs">
        <span className="font-sans uppercase">{lang}</span>
        <div className="flex items-center space-x-2">
            {lang === 'html' && (
                <button
                    onClick={() => setShowHtmlPreview(true)}
                    className="flex items-center text-gray-300 hover:text-white transition-colors"
                    aria-label="Preview HTML"
                >
                    <EyeIcon className="w-4 h-4 mr-1" />
                    Preview
                </button>
            )}
            <button
                onClick={handleCopy}
                className="flex items-center text-gray-300 hover:text-white transition-colors"
                aria-label="Copy code"
            >
            {copied ? (
                <>
                    <CheckIcon className="w-4 h-4 mr-1 text-green-400" />
                    Copied!
                </>
            ) : (
                <>
                    <CopyIcon className="w-4 h-4 mr-1" />
                    Copy
                </>
            )}
            </button>
        </div>
      </div>
      <div className="max-h-60 overflow-y-auto">
        <SyntaxHighlighter
            style={atomDark}
            language={lang}
            PreTag="div"
            customStyle={{ margin: 0 }}
        >
            {rawCode}
        </SyntaxHighlighter>
      </div>
      {showHtmlPreview && lang === 'html' && (
          <PreviewModal htmlContent={rawCode} onClose={() => setShowHtmlPreview(false)} />
      )}
    </div>
  );
};