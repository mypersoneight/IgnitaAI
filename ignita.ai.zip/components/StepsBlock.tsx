
import React from 'react';
import { DownloadIcon } from './icons';

interface StepsBlockProps {
  children: React.ReactNode;
}

export const StepsBlock = ({ children }: StepsBlockProps) => {
  const downloadSteps = () => {
    let textContent = '';
    
    // FIX: A more robust, recursive function to extract text content from complex React nodes.
    const extractText = (node: React.ReactNode): string => {
        if (node === null || typeof node === 'undefined') return '';
        if (typeof node === 'string' || typeof node === 'number') return String(node);
        if (Array.isArray(node)) return node.map(extractText).join('');
        if (React.isValidElement<{ children?: React.ReactNode }>(node) && node.props.children) {
            return extractText(node.props.children);
        }
        return '';
    };

    // FIX: Use type guard `React.isValidElement` with explicit props to fix TypeScript errors.
    React.Children.forEach(children, (child) => {
      if (React.isValidElement<{ children?: React.ReactNode }>(child) && child.props.children) {
        let stepCounter = 1;
        React.Children.forEach(child.props.children, (listItem) => {
            if (React.isValidElement<{ children?: React.ReactNode }>(listItem) && listItem.props.children) {
                textContent += `${stepCounter}. ${extractText(listItem.props.children)}\n`;
                stepCounter++;
            }
        });
      }
    });

    const blob = new Blob([textContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'steps.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="my-4 p-4 border border-primary-200 dark:border-primary-800 bg-primary-50 dark:bg-primary-900/20 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-semibold text-primary-700 dark:text-primary-300">Here are the steps:</h3>
        <button
          onClick={downloadSteps}
          className="flex items-center px-3 py-1.5 text-sm font-medium text-primary-600 dark:text-primary-400 bg-white dark:bg-gray-800 border border-primary-200 dark:border-primary-700 rounded-md hover:bg-primary-100 dark:hover:bg-primary-900 transition-colors"
          aria-label="Download steps"
        >
          <DownloadIcon className="w-4 h-4 mr-2" />
          Download Steps
        </button>
      </div>
      <div className="prose prose-sm dark:prose-invert max-w-none prose-li:my-1">
        {children}
      </div>
    </div>
  );
};
