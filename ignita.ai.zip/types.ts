

export interface Source {
  uri: string;
  title: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  sources?: Source[];
  audioUrl?: string;
}

export interface Location {
  latitude: number;
  longitude: number;
}

export type PromptMode = 'none' | 'explain' | 'code' | 'research' | 'short';

// FIX: Added the AIStudio interface to centralize type definitions and resolve global type conflicts.
export interface AIStudio {
  hasSelectedApiKey: () => Promise<boolean>;
  openSelectKey: () => Promise<void>;
}
